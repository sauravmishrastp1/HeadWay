package com.headwayagent.salesadviser_headwaygms.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.R;
import com.headwayagent.salesadviser_headwaygms.Registeration_Activity;
import com.headwayagent.salesadviser_headwaygms.SharedPreference.SharedPrefManager;
import com.headwayagent.salesadviser_headwaygms.models.UserDetails;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    Button login_btn;

    private EditText aintextview;
    private EditText passwordtextview;
    private TextView textView;
    private static final int MY_PERMISSIONS_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login_btn=findViewById(R.id.loginbtn);
        textView = findViewById(R.id.create);
        aintextview=findViewById(R.id.AIN_Number);
        passwordtextview=findViewById(R.id.password);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               login();
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, Registeration_Activity.class);
                startActivity(intent);
            }
        });
    }




    private void login() {

        final String ain_number=aintextview.getText().toString();
        final String password=passwordtextview.getText().toString();


        if (TextUtils.isEmpty(ain_number)) {
            aintextview.setError("Please enter your AIN Number");
            aintextview.requestFocus();
            return;
        } else if (TextUtils.isEmpty(password)) {
            passwordtextview.setError("Please enter your password");
            passwordtextview.requestFocus();
            return;
        } else {


            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setIcon(R.drawable.headwaygmslogo);
            progressDialog.setTitle("Login.....");
            progressDialog.setMessage("Please wait......");
            progressDialog.show();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.URL_EMP_LOGIN,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                //converting response to json object

                                JSONObject obj = new JSONObject(response);

                                String message = obj.getString("msg");


                                if (message.equals("Success")) {

                                    String offer_letter = obj.getString("offer");
                                    JSONObject jsonObject = obj.getJSONObject("user");
                                    String downline=obj.getString("downline");
                                    String order=obj.getString("order");
                                    String department = jsonObject.getString("department");
                                    String sponsor_name = jsonObject.getString("sponsor_name");
                                    String sponsor_id = jsonObject.getString("sponsor_id");
                                    String module_name = jsonObject.getString("module_name");
                                    String title = jsonObject.getString("title");
                                    String ain = jsonObject.getString("ain");
                                    String status = jsonObject.getString("status");
                                    String full_name = jsonObject.getString("full_name");
                                    String sdw = jsonObject.getString("sdw");
                                    String aadhaar_number = jsonObject.getString("aadhaar_number");
                                    String designation = jsonObject.getString("designation");
                                    String address = jsonObject.getString("address");
                                    String city = jsonObject.getString("city");
                                    String state = jsonObject.getString("state");
                                    String pin = jsonObject.getString("pin");
                                    String email = jsonObject.getString("email");
                                    String userid=jsonObject.getString("id");
                                    String pan = jsonObject.getString("pan");
                                    String phone = jsonObject.getString("phone");
                                    String nominee_name = jsonObject.getString("nominee_name");
                                    String relationship = jsonObject.getString("relationship");
                                    String nominee_dob = jsonObject.getString("nominee_dob");
                                    String account_holder = jsonObject.getString("account_holder");
                                    String bank = jsonObject.getString("bank");
                                    String branch = jsonObject.getString("branch");
                                    String ifsc = jsonObject.getString("ifsc");
                                    String account_number = jsonObject.getString("account_number");
                                    String account_type = jsonObject.getString("account_type");
                                    String pic = jsonObject.getString("pic");
                                    String aadhaar_doc = jsonObject.getString("aadhaar_doc");

                                    UserDetails user = new UserDetails(ain,password,phone,department,title,full_name,pic,module_name,city,state,email,address,pin,sponsor_name,sponsor_id,sdw,designation,aadhaar_number,nominee_name,nominee_dob,relationship,pan,account_holder,bank,account_number,ifsc,offer_letter,status,userid,downline,order);

                                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);
                                    Intent intent=new Intent(getApplicationContext(), CheckInActivity.class);
                                    startActivity(intent);
                                    LoginActivity.this.finish();
                                    progressDialog.dismiss();
                                    return;
                                } else {
                                    Toast.makeText(getApplicationContext(), ""+obj.getString("msg"), Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();
                                }
                            } catch (JSONException e) {
                                Toast.makeText(LoginActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                e.printStackTrace();
                                progressDialog.dismiss();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "Server Not Respondin Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("ain", ain_number);
                    params.put("password", password);
                    return params;
                }
            };

            VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
        }

    }


    @Override
    protected void onStart() {
        super.onStart();
        requestStoragePermission();
    }

    protected void requestStoragePermission(){
        if(ContextCompat.checkSelfPermission(
                this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){

            // Do something, when permissions not granted
            if(ActivityCompat.shouldShowRequestPermissionRationale(
                    this,Manifest.permission.WRITE_EXTERNAL_STORAGE)){

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Storage permissions are required to do the task.");
                builder.setTitle("Please grant those permissions");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(
                                LoginActivity.this,
                                new String[]{
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                                },
                                MY_PERMISSIONS_REQUEST_CODE
                        );
                    }
                });
                builder.setNeutralButton("Cancel",null);
                AlertDialog dialog = builder.create();
                dialog.show();
            }else{
                // Directly request for required permissions, without explanation
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                        },
                        MY_PERMISSIONS_REQUEST_CODE
                );
            }
        }else {
            // Do something, when permissions are already granted
            Toast.makeText(this,"Permissions already granted",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_CODE:{
                // When request is cancelled, the results array are empty
                if(
                        (grantResults.length >0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED
                                )
                ){
                    // Permissions are granted
                    Toast.makeText(this,"Permissions granted.",Toast.LENGTH_SHORT).show();
                }else {
                    // Permissions are denied
                    Toast.makeText(this,"Permissions denied.",Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

}



