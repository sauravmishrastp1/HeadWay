package com.headwayagent.salesadviser_headwaygms.models;

public class Spinner_ItemModel {

    private String spinnerItemName;

    public String getSpinnerItemName() {
        return spinnerItemName;
    }

    public void setSpinnerItemName(String spinnerItemName) {
        this.spinnerItemName = spinnerItemName;
    }

    public Spinner_ItemModel(String spinnerItemName) {
        this.spinnerItemName = spinnerItemName;
    }
}
