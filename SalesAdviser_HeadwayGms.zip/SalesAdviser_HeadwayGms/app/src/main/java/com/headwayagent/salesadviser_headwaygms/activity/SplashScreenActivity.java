package com.headwayagent.salesadviser_headwaygms.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.headwayagent.animation.ProgressbarAnimation;
import com.headwayagent.salesadviser_headwaygms.R;

public class SplashScreenActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView   value_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        progressBar=findViewById(R.id.progressBar);
        value_tv=findViewById(R.id.value_textview);

        progressBar.setMax(100);
        progressBar.setScaleY(3f);

        progressBarAnimation();


    }

    private void progressBarAnimation()
    {

        ProgressbarAnimation progressbarAnimation=new ProgressbarAnimation(progressBar,SplashScreenActivity.this,value_tv,0,100);
        progressbarAnimation.setDuration(8000);
        progressBar.setAnimation(progressbarAnimation);

    }
}
