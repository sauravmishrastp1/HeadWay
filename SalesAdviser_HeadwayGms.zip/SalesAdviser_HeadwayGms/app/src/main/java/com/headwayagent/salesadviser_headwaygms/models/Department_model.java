package com.headwayagent.salesadviser_headwaygms.models;

public class Department_model {


    private String spinnerItemName;

    public String getSpinnerItemName() {
        return spinnerItemName;
    }

    public void setSpinnerItemName(String spinnerItemName) {
        this.spinnerItemName = spinnerItemName;
    }

    public Department_model(String spinnerItemName) {
        this.spinnerItemName = spinnerItemName;
    }
}
