package com.headwayagent.salesadviser_headwaygms;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.SharedPreference.SharedPrefManager;
import com.headwayagent.salesadviser_headwaygms.activity.CheckInActivity;
import com.headwayagent.salesadviser_headwaygms.activity.LoginActivity;
import com.headwayagent.salesadviser_headwaygms.adapter.Department_Adapter;
import com.headwayagent.salesadviser_headwaygms.adapter.SpinnerItemAdapter;
import com.headwayagent.salesadviser_headwaygms.adapter.Spinner_ItemAdapter;
import com.headwayagent.salesadviser_headwaygms.models.Department_model;
import com.headwayagent.salesadviser_headwaygms.models.SpinnerItemModel;
import com.headwayagent.salesadviser_headwaygms.models.Spinner_ItemModel;
import com.headwayagent.salesadviser_headwaygms.models.UserDetails;
import com.theartofdev.edmodo.cropper.CropImage;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Registeration_Activity extends AppCompatActivity {
    EditText nameEt, adharEt, sdwoEt, addressEt, cityEt, pincodeEt, emailEt, dobEt, pancardEt, mobilenoEt, nomineenameEt,
            relationshpEt, nomineedobEt, bankholdernameEt, banknameEt, banacountnoEt, branchEt, ifscEt, stateEt;
    Spinner dapartmentSp, genderSp;
    RadioButton cdachannalradiobtn, savingacountradiobtn, cruntaccountradiobtn;
    Calendar calendar;
    int year, date, month;
    Button registerbutton, chooseadharcard, choosepancard;
    private List<Spinner_ItemModel> genderlist = new ArrayList<>();
    private List<Department_model> department_models = new ArrayList<>();
    String gender;
    String department;
    private static final int GALLERY_IMAGE = 1;
    private Uri uri;
    ProgressDialog progressDialog;
    String mUri = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeration_);
        dapartmentSp = findViewById(R.id.department);
        genderSp = findViewById(R.id.gender);
        stateEt = findViewById(R.id.state);

        nameEt = findViewById(R.id.fullname);
        adharEt = findViewById(R.id.adharno);
        sdwoEt = findViewById(R.id.sofdof);
        addressEt = findViewById(R.id.address);
        cityEt = findViewById(R.id.city);
        pincodeEt = findViewById(R.id.pincode);
        emailEt = findViewById(R.id.email);
        dobEt = findViewById(R.id.dob);
        pancardEt = findViewById(R.id.pancardno);
        mobilenoEt = findViewById(R.id.mobileno);
        nomineenameEt = findViewById(R.id.nomeniname);
        relationshpEt = findViewById(R.id.relationship);
        nomineedobEt = findViewById(R.id.nomeneedob);
        bankholdernameEt = findViewById(R.id.AccountHolderName);
        banknameEt = findViewById(R.id.BankName);
        banacountnoEt = findViewById(R.id.BankAccountNumber);
        branchEt = findViewById(R.id.Branch);
        ifscEt = findViewById(R.id.IFSC);
        calendar = Calendar.getInstance();
        date = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        year = calendar.get(Calendar.YEAR);
        registerbutton = findViewById(R.id.submit_datafile);


        month = month + 1;

        dobEt.setText(date + "-" + month + "-" + year);

        dobEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Registeration_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthofyear, int dayOfMonth) {
                        monthofyear = monthofyear + 1;
                        dobEt.setText(dayOfMonth + "-" + monthofyear + "-" + year);
                    }
                }, year, month, date);
                datePickerDialog.show();
            }


        });
        nomineedobEt.setText(date + "-" + month + "-" + year);

        nomineedobEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Registeration_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthofyear, int dayOfMonth) {
                        monthofyear = monthofyear + 1;
                        nomineedobEt.setText(dayOfMonth + "-" + monthofyear + "-" + year);
                    }
                }, year, month, date);
                datePickerDialog.show();
            }


        });

        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });


        genderlist = getGenderList();

        Spinner_ItemAdapter genderadapter = new Spinner_ItemAdapter(this, (ArrayList<Spinner_ItemModel>) genderlist);

        if (genderSp != null) {
            genderSp.setAdapter(genderadapter);

            genderSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    Spinner_ItemModel model = (Spinner_ItemModel) parent.getSelectedItem();

                    gender = model.getSpinnerItemName();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }

        department_models = getdepartment_models();

        Department_Adapter adapter = new Department_Adapter(this, (ArrayList<Department_model>) department_models);

        if (dapartmentSp != null) {
            dapartmentSp.setAdapter(adapter);

            dapartmentSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    Department_model model = (Department_model) parent.getSelectedItem();

                    department = model.getSpinnerItemName();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
        chooseadharcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                choosefile();
            }
        });

    }


    private void register() {

        final String fullname = nameEt.getText().toString();
        final String adharno = adharEt.getText().toString();
        final String sodo = sdwoEt.getText().toString();
        final String address = addressEt.getText().toString();
        final String city = cityEt.getText().toString();
        final String pincode = pincodeEt.getText().toString();
        final String email = emailEt.getText().toString();
        final String dateofbirth = dobEt.getText().toString();
        final String pancardno = pancardEt.getText().toString();
        final String mobileno = mobilenoEt.getText().toString();
        final String nominee_name = nameEt.getText().toString();
        final String relationship = relationshpEt.getText().toString();
        final String namineedob = nomineedobEt.getText().toString();
        final String acountholdername = bankholdernameEt.getText().toString();
        final String bankename = banknameEt.getText().toString();
        final String branch = branchEt.getText().toString();
        final String ifsc = ifscEt.getText().toString();
        final String sate = stateEt.getText().toString();

        if (TextUtils.isEmpty(fullname)) {
            nameEt.setError("Field is empty");
            nameEt.requestFocus();
            return;
        } else if (TextUtils.isEmpty(adharno)) {
            adharEt.setError("Field is empty");
            adharEt.requestFocus();
            return;

        } else if (TextUtils.isEmpty(sodo)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(address)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(city)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(pincode)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(email)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(dateofbirth)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(pancardno)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(mobileno)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(nominee_name)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(relationship)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(namineedob)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(acountholdername)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(bankename)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(branch)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(ifsc)) {
            sdwoEt.setError("Field is empty");
            return;
        } else if (TextUtils.isEmpty(sate)) {
            stateEt.setError("Field is empty");
            return;
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setIcon(R.drawable.headwaygmslogo);
            progressDialog.setTitle("Register.....");
            progressDialog.setMessage("Please wait......");
            progressDialog.show();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.REGISTRATION,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                //converting response to json object

                                JSONObject obj = new JSONObject(response);

                                String message = obj.getString("msg");


                                if (message.equals("Success")) {


                                    Intent intent = new Intent(getApplicationContext(), CheckInActivity.class);
                                    startActivity(intent);
                                    Registeration_Activity.this.finish();
                                    progressDialog.dismiss();
                                    return;
                                } else {
                                    Toast.makeText(getApplicationContext(), "" + obj.getString("msg"), Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();
                                }
                            } catch (JSONException e) {
                                Toast.makeText(Registeration_Activity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                e.printStackTrace();
                                progressDialog.dismiss();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "Server Not Respondin Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("name", fullname);
                    params.put("email", email);
                    params.put("phone", mobileno);
                    params.put("aadhaar_number", adharno);
                    params.put("sdw", sodo);
                    params.put("address", address);
                    params.put("city", city);
                    params.put("pin", pincode);
                    params.put("dob", dateofbirth);
                    params.put("pan", pancardno);
                    params.put("nominee_name", nominee_name);
                    params.put("relationship", relationship);
                    params.put("nominee_dob", namineedob);
                    params.put("account_holder", acountholdername);
                    params.put("bank", bankename);
                    params.put("account_number", address);
                    params.put("branch", branch);
                    params.put("ifsc", ifsc);
                    //params.put("account_type", );
                    params.put("state", sate);
                    params.put("title", gender);
                    // params.put("module_name", password);
                    return params;
                }
            };

            VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
        }
    }

    private ArrayList<Spinner_ItemModel> getGenderList() {


        genderlist.add(new Spinner_ItemModel(getResources().getString(R.string.genderlist)));
        genderlist.add(new Spinner_ItemModel(getResources().getString(R.string.male)));
        genderlist.add(new Spinner_ItemModel(getResources().getString(R.string.female)));
        genderlist.add(new Spinner_ItemModel(getResources().getString(R.string.ms)));

        return (ArrayList<Spinner_ItemModel>) genderlist;
    }

    private ArrayList<Department_model> getdepartment_models() {


        department_models.add(new Department_model(getResources().getString(R.string.department)));
        department_models.add(new Department_model(getResources().getString(R.string.employee)));


        return (ArrayList<Department_model>) department_models;
    }

    private void choosefile() {

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, GALLERY_IMAGE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri ImageUri = data.getData();

        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK) {

                uri = result.getUri();

                mUri = uri.toString();

                //profilepicView.setImageURI(uri);


            }

        }



    }
}


