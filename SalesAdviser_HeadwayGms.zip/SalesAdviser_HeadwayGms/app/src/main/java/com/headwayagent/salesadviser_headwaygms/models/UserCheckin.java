package com.headwayagent.salesadviser_headwaygms.models;

public class UserCheckin {

    private  String ain;

    public UserCheckin(String ain) {
        this.ain = ain;
    }


    public String getAin() {
        return ain;
    }

    public void setAin(String ain) {
        this.ain = ain;
    }
}
