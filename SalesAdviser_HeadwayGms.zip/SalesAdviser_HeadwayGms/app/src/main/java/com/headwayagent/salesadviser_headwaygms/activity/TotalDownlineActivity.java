package com.headwayagent.salesadviser_headwaygms.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.R;
import com.headwayagent.salesadviser_headwaygms.SharedPreference.SharedPrefManager;
import com.headwayagent.salesadviser_headwaygms.adapter.TotalDownlineAdapter;
import com.headwayagent.salesadviser_headwaygms.models.TotalDownlineModel;
import com.headwayagent.salesadviser_headwaygms.models.UserDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TotalDownlineActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private Toolbar toolbar;
    private String ain;
    private View oopslinear;
    private List<TotalDownlineModel> totalDownlineModelList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_downline);

        recyclerView = findViewById(R.id.totaldownline_recycler);
        progressBar = findViewById(R.id.progressBar);
        toolbar = findViewById(R.id.toolbar);
        oopslinear=findViewById(R.id.oopslinear);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Total Downline");
        UserDetails userDetails = SharedPrefManager.getInstance(TotalDownlineActivity.this).getUser();
        ain=userDetails.getAin_number();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        getTotalDownline();

    }






    private void getTotalDownline() {

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.VIEW_DOWNLINE+ain,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject obj = new JSONObject(response);
                            String message = obj.getString("msg");

                            if (message.equals("Success")) {

                                JSONArray productsArray = obj.getJSONArray("order");

                                for (int y = 0; y < productsArray.length(); y++) {

                                    JSONObject jsonObject = productsArray.getJSONObject(y);

                                    String ain = jsonObject.getString("ain");
                                    String order_total = jsonObject.getString("order_total");

                                    totalDownlineModelList.add(new TotalDownlineModel(ain,order_total));


                                }

                                TotalDownlineAdapter totalDownlineAdapter = new TotalDownlineAdapter(totalDownlineModelList, TotalDownlineActivity.this);
                                recyclerView.setAdapter(totalDownlineAdapter);
                                totalDownlineAdapter.notifyDataSetChanged();
                                progressBar.setVisibility(View.GONE);

                                progressBar.setVisibility(View.GONE);
                            } else {
                                Toast.makeText(getApplicationContext(), "You Have No Downline "+obj.getString("msg"), Toast.LENGTH_LONG).show();
                                oopslinear.setVisibility(View.VISIBLE);
                                progressBar.setVisibility(View.GONE);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(TotalDownlineActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Server Not Responding Check Inernet Connection", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
