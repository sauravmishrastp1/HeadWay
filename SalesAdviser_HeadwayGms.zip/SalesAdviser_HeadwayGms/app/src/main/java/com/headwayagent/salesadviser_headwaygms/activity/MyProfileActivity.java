package com.headwayagent.salesadviser_headwaygms.activity;

import android.app.DownloadManager;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.R;
import com.headwayagent.salesadviser_headwaygms.SharedPreference.SharedPrefManager;
import com.headwayagent.salesadviser_headwaygms.models.UserDetails;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MyProfileActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private Button checkout_btn, downloadOfferlater;
    private String ain_number, profileimg_url;
    private TextView Aintv, profilestatus_tv, phonetv, addess_tv, usernametv, useremailtv;
    private TextView AcTv, AcHolderNameTv, bankNameTv, IfscTv;
    private TextView nominee_name_tv, relationshiptv, dob_tv;
    private ImageView profile_imageview;
    private Uri Download_Uri;
    private long downloadID;
    ArrayList<Long> list = new ArrayList<>();
    private DownloadManager downloadManager;
    private BroadcastReceiver onComplete;
    private String ain,type="";
    private String offerlater;
    private TextView designationTv;
    private String profilestatus, phone,designation, address, nomineename, username, useremail, Ac, acholdername, bankname, ifsc;
    private String relationship, dob;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Profile");
        checkout_btn = findViewById(R.id.checkout_button);
        Aintv = findViewById(R.id.ain_tv);
        profilestatus_tv = findViewById(R.id.profile_status_tv);
        phonetv = findViewById(R.id.phone_tv);
        addess_tv = findViewById(R.id.addresstv);
        usernametv = findViewById(R.id.user_name);
        useremailtv = findViewById(R.id.emailtv);
        AcTv = findViewById(R.id.bank_account_tv);
        AcHolderNameTv = findViewById(R.id.account_holder_name_tv);
        bankNameTv = findViewById(R.id.bank_name_tv);
        designationTv=findViewById(R.id.designation);
        IfscTv = findViewById(R.id.ifsc_tv);
        nominee_name_tv = findViewById(R.id.nominee_namee_tv);
        relationshiptv = findViewById(R.id.relationship_tv);
        dob_tv = findViewById(R.id.dob_tv);
        profile_imageview = findViewById(R.id.profile_image);
        downloadOfferlater = findViewById(R.id.dwnld_offer_letter_btn);
        progressBar = findViewById(R.id.progressBar);


        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            type = bundle.getString("type");
            ain = bundle.getString("ain");

        }

        if (type.equals("downline")) {
            downloadOfferlater.setVisibility(View.GONE);
            checkout_btn.setVisibility(View.GONE);
            Toast.makeText(this, "ain=" + ain, Toast.LENGTH_SHORT).show();
            getProfileData();
        }

        else if (type.equals("indirect"))
        {
            downloadOfferlater.setVisibility(View.GONE);
            checkout_btn.setVisibility(View.GONE);
            Toast.makeText(this, "ain=" + ain, Toast.LENGTH_SHORT).show();
            getProfileData();
        }
        else {

            downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            UserDetails userDetails = SharedPrefManager.getInstance(this).getUser();
            ain_number = userDetails.getAin_number();
            profilestatus = userDetails.getProfile_status();
            phone = userDetails.getPhone();
            address = userDetails.getAddress();
            nomineename = userDetails.getNominee_name();
            username = userDetails.getFull_name();
            useremail = userDetails.getEmail();
            designation=userDetails.getDesignation();
            Ac = userDetails.getAccount_number();
            acholdername = userDetails.getAccount_holder_name();
            bankname = userDetails.getBank_name();
            ifsc = userDetails.getIfsc();
            relationship = userDetails.getNomibee_relation();
            dob = userDetails.getNominee_dob();
            profileimg_url = userDetails.getProfile_image();
            offerlater = userDetails.getOfferLater();
            Aintv.setText(ain_number);
            if (profilestatus.equals("1")) {
                profilestatus_tv.setText("Not Approved");
            } else {
                profilestatus_tv.setText("Approved");

            }
            phonetv.setText(phone);
            addess_tv.setText(address);
            nominee_name_tv.setText(nomineename);
            usernametv.setText(username);
            useremailtv.setText(useremail);
            AcTv.setText(Ac);
            AcHolderNameTv.setText(acholdername);
            bankNameTv.setText(bankname);
            IfscTv.setText(ifsc);
            designationTv.setText(designation);
            relationshiptv.setText(relationship);
            dob_tv.setText(dob);
            nominee_name_tv.setText(nomineename);
            // sponser_nameTv.setText(sponserName);
            // sponserId_tv.setText(sponserId);


            Picasso.get()
                    .load("https://www.headwaygms.com/" + profileimg_url)
                    .placeholder(R.drawable.profileimageicon)
                    .error(R.drawable.profileimageicon)
                    .into(profile_imageview);

            checkout_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    checkout(ain_number);
                }


            });


            this.registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

            downloadOfferlater.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View view) {


                    Download_Uri = Uri.parse("http://www.headwaygms.com/" + offerlater);
                    DownloadManager.Request request = new DownloadManager.Request(Download_Uri);
                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
                    request.setAllowedOverRoaming(false);
                    request.setTitle("offer later " + username + ".png");
                    request.setDescription("Downloading " + "offer later" + ".pdf");
                    request.setVisibleInDownloadsUi(true);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Headway/" + "/OFFER LATER/" + "/" + username + ".pdf");
                    downloadID = downloadManager.enqueue(request);
                    list.add(downloadID);


                }
            });


            onComplete = new BroadcastReceiver() {

                public void onReceive(Context ctxt, Intent intent) {

                    // get the refid from the download manager
                    long referenceId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

// remove it from our list
                    list.remove(referenceId);

// if list is empty means all downloads completed
                    if (list.isEmpty()) {

// show a notification
                        Log.e("INSIDE", "" + referenceId);
                        NotificationCompat.Builder mBuilder =
                                new NotificationCompat.Builder(MyProfileActivity.this)
                                        .setSmallIcon(R.mipmap.ic_launcher)
                                        .setContentTitle("Offer Later's" + username)
                                        .setContentText("Download completed");


                        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        notificationManager.notify(455, mBuilder.build());


                    }

                }
            };


        }
    }



    private void checkout(String ain_number) {

        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Please wait..");
        progressDialog.setIcon(R.drawable.headwaygmslogo);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.URL_CHECKOUT+ain_number,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject obj = new JSONObject(response);
                            String message = obj.getString("msg");

                            if (message.equals("Success")) {

                                progressDialog.dismiss();
//                                SharedPrefManager.getInstance(MyProfileActivity.this).checkOut();
                                startActivity(new Intent(MyProfileActivity.this,CheckInActivity.class));
                                finish();


                            } else {
                                Toast.makeText(getApplicationContext(), obj.getString("msg"), Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Server Not Responding", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }) {

        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


    private void getProfileData()
    {
        progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, BaseUrl.VIEW_PROFILE+ain,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject obj = new JSONObject(response);
                            String message = obj.getString("msg");
                            JSONObject object=obj.getJSONObject("profile");

                            if (message.equals("Success")) {

                                profilestatus=object.getString("status");
                                phone=object.getString("phone");
                                address=object.getString("address");
                                Ac=object.getString("account_number");
                                acholdername=object.getString("account_holder");
                                bankname=object.getString("bank");
                                ifsc=object.getString("ifsc");
                                nomineename=object.getString("nominee_name");
                                relationship=object.getString("relationship");
                                dob=object.getString("dob");
                                profileimg_url=object.getString("pic");
                                username=object.getString("full_name");
                                useremail=object.getString("email");
                                designation=object.getString("designation");
                                Aintv.setText(ain);
                                phonetv.setText(phone);
                                addess_tv.setText(address);
                                nominee_name_tv.setText(nomineename);
                                usernametv.setText(username);
                                useremailtv.setText(useremail);
                                AcTv.setText(Ac);
                                AcHolderNameTv.setText(acholdername);
                                bankNameTv.setText(bankname);
                                IfscTv.setText(ifsc);
                                designationTv.setText(designation);
                                relationshiptv.setText(relationship);
                                dob_tv.setText(dob);
                                nominee_name_tv.setText(nomineename);
                                usernametv.setText(username);
                                useremailtv.setText(useremail);
                                Picasso.get()
                                        .load("https://www.headwaygms.com/" + profileimg_url)
                                        .placeholder(R.drawable.profileimageicon)
                                        .error(R.drawable.profileimageicon)
                                        .into(profile_imageview);

                                if (profilestatus.equals("1")) {
                                    profilestatus_tv.setText("Not Approved");
                                }
                                else {
                                    profilestatus_tv.setText("Approved");

                                }

                             progressBar.setVisibility(View.GONE);
                            } else {
                                Toast.makeText(getApplicationContext(), obj.getString("msg"), Toast.LENGTH_SHORT).show();
                               progressBar.setVisibility(View.GONE);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(MyProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                           progressBar.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Server Not Responding Check Inernet Connection", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
