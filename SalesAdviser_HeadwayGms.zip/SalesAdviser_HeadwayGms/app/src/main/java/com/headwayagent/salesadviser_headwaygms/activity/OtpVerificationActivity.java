package com.headwayagent.salesadviser_headwaygms.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OtpVerificationActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private Button submitbtn;
    private EditText happycodeET;
    private ProgressDialog progressDialog;
    private String happy_code,orderid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        toolbar=findViewById(R.id.toolbarservice);
        submitbtn=findViewById(R.id.submitotp);
        happycodeET=findViewById(R.id.happycode);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Happy Code Verfication");

        Bundle bundle=getIntent().getExtras();
        orderid=bundle.getString("order-id");

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                happy_code=happycodeET.getText().toString();

                if (happy_code.equals(""))
                {
                    Toast.makeText(OtpVerificationActivity.this, "Please Enter Happy Code", Toast.LENGTH_SHORT).show();
                }

                else {
                    verifyOtp();
                }

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void verifyOtp()
    {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.URL_VERIFY_HAPPY_CODE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject obj = new JSONObject(response);
                            String message = obj.getString("msg");
                            String status = obj.getString("status");

                            if (status.equals("200")) {
                                Intent intent=new Intent(OtpVerificationActivity.this,SalesDashBoardActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();

                            } else {
                                Toast.makeText(OtpVerificationActivity.this, obj.getString("msg"), Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(OtpVerificationActivity.this, "exception", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(OtpVerificationActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("happy_code", happy_code);
                params.put("order_id", orderid);


                return params;
            }
        };

        VolleySingleton.getInstance(OtpVerificationActivity.this).addToRequestQueue(stringRequest);

    }
}
