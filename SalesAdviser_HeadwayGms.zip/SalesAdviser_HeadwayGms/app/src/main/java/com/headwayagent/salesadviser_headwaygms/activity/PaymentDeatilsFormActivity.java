package com.headwayagent.salesadviser_headwaygms.activity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.BaseUrl;
import com.headwayagent.salesadviser_headwaygms.API_Integration_Asset.VolleySingleton;
import com.headwayagent.salesadviser_headwaygms.R;
import com.headwayagent.salesadviser_headwaygms.SharedPreference.SharedPrefManager;
import com.headwayagent.salesadviser_headwaygms.adapter.SpinnerItemAdapter;
import com.headwayagent.salesadviser_headwaygms.models.SpinnerItemModel;
import com.headwayagent.salesadviser_headwaygms.models.UserDetails;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class PaymentDeatilsFormActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Toolbar toolbar;
    Spinner spinner;
    ArrayList<SpinnerItemModel> list;
   static TextView datebtn;
   static TextView timebtn;
   static String time="",date="";
   String paymentType;
   Button placeOrderButton;
   String p_img,p_price,p_title,p_discription;
    private int mYear, mMonth, mDay, mHour, mMinute;
   String pid,quantity,name,email,phone,address1,address2,city,state,pin,alternatephone,user_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_deatils_form);
        toolbar=findViewById(R.id.toolbarservice);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Payment Details");
        toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        spinner=findViewById(R.id.myspinner);
        datebtn=findViewById(R.id.date);
        timebtn=findViewById(R.id.time);
        placeOrderButton=findViewById(R.id.place_order_btn);


        Bundle extras = getIntent().getExtras();

        pid=extras.getString("pid");
        quantity=extras.getString("qty");
        name=extras.getString("name");
        email=extras.getString("email");
        phone=extras.getString("phone");
        address1=extras.getString("address1");
        address2=extras.getString("address2");
        city=extras.getString("city");
        state=extras.getString("state");
        pin=extras.getString("pin");
        alternatephone=extras.getString("alternate_phone");
        final String type=extras.getString("type");

        p_img=extras.getString("image");
        p_price=extras.getString("p_price");
        Toast.makeText(this, "price="+p_price, Toast.LENGTH_SHORT).show();
        p_title=extras.getString("title");
        p_discription=extras.getString("p_discription");

        UserDetails userDetails = SharedPrefManager.getInstance(PaymentDeatilsFormActivity.this).getUser();
        //user_id=userDetails.getUserid();
        user_id=userDetails.getAin_number();


        placeOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (type.equals("sales")) {

                   // Toast.makeText(PaymentDeatilsFormActivity.this, "qty=" + quantity + " " + pid + " " + name + " " + email + " " + phone + " " + address1 + " " + address2 + " " + city + " " + "" + state + " " + pin + " " + " " + " " + alternatephone + "" + " " + time + " " + date + " " + paymentType + "userid=" + user_id, Toast.LENGTH_LONG).show();

                    if (time.equals(""))
                    {
                        Toast.makeText(PaymentDeatilsFormActivity.this, "Please Select Time", Toast.LENGTH_SHORT).show();
                    }

                    else if (date.equals("")){
                        Toast.makeText(PaymentDeatilsFormActivity.this, "Please Select Date", Toast.LENGTH_SHORT).show();
                    }

                    else {

                        placeOrder();
                    }
                }

                else {
                    if (time.equals(""))
                    {
                        Toast.makeText(PaymentDeatilsFormActivity.this, "Please Select Time", Toast.LENGTH_SHORT).show();
                    }

                    else if (date.equals("")){
                        Toast.makeText(PaymentDeatilsFormActivity.this, "Please Select Date", Toast.LENGTH_SHORT).show();
                    }

                    else {

                        placeServiceOrder();
                    }
                }
            }
        });

        datebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                DialogFragment newFragment = new DatePickerFragment();
//                newFragment.show(getSupportFragmentManager(), "timePicker");


                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(PaymentDeatilsFormActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {


                                PaymentDeatilsFormActivity.date = dayOfMonth + "-" + monthOfYear + "-" + year;
                                datebtn.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);


                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();



            }
        });


        timebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                DialogFragment newFragment = new TimePickerFragment();
//               // getSupportActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
//                newFragment.show(getSupportFragmentManager(), "timePicker");


                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(PaymentDeatilsFormActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                timebtn.setText(hourOfDay + ":" + minute);
                                PaymentDeatilsFormActivity.time=hourOfDay+" : "+minute;


                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });



        list=getList();

        SpinnerItemAdapter spinnerItemAdapter=new SpinnerItemAdapter(this,list);
        if (spinner!=null) {
            spinner.setAdapter(spinnerItemAdapter);
            spinner.setOnItemSelectedListener(this);
        }




    }

    private ArrayList<SpinnerItemModel> getList() {

        list=new ArrayList<>();
        list.add(new SpinnerItemModel("COD",R.drawable.cod));
//        list.add(new SpinnerItemModel("Net Banking",R.drawable.netbanking));
//        list.add(new SpinnerItemModel("Card Payment",R.drawable.ic_credit_card_black_24dp));
//        list.add(new SpinnerItemModel("UPI",R.drawable.netbanking));
//        list.add(new SpinnerItemModel("Paytm",R.drawable.paytm));
        return list;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        SpinnerItemModel model= (SpinnerItemModel) parent.getSelectedItem();
        paymentType=model.getSpinnerItemName();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    private void  placeOrder()
    {

        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setIcon(R.drawable.headwaygmslogo);
        progressDialog.setTitle("Placing Order");
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.URL_PLACE_ORDER_SALES,

                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject jsonObject=new JSONObject(response);

                            String message=jsonObject.getString("msg");

                            JSONObject object=jsonObject.getJSONObject("order");

                            String orderId=  object.getString("order_id");



                            if (message.equals("Success"))
                            {

                                Intent intent=new Intent(PaymentDeatilsFormActivity.this,OrderDetailsActivity.class);
                                  intent.putExtra("Orderid",orderId);
                                  intent.putExtra("intent_type","sales");
                                  intent.putExtra("backtype","1");
                                  startActivity(intent);
                                  finish();
                                progressDialog.dismiss();
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(PaymentDeatilsFormActivity.this, "hello="+e.toString(), Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                       // Toast.makeText(PaymentDeatilsFormActivity.this, " error null", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("product_id", pid);
                params.put("name", name);
                params.put("email", email);
                params.put("phone", phone);
                params.put("address1", address1);
                params.put("address2", address2);
                params.put("city", city);
                params.put("state", state);
                params.put("pin", pin);
                params.put("alternate_phone", alternatephone);
                params.put("quantity",quantity);
                params.put("payment_type",paymentType);
                params.put("delivery_time", time);
                params.put("delivery_date", date);
                params.put("price",p_price);
                params.put("user_id",user_id);

                return params;
            }
        };

        queue.getCache().clear();
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }


    private void placeServiceOrder()
    {
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setIcon(R.drawable.headwaygmslogo);
        progressDialog.setTitle("Placing Order");
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, BaseUrl.URL_PLACE_SERVICE_ORDER_SALES,

                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject jsonObject=new JSONObject(response);

                            String message=jsonObject.getString("msg");

                            Toast.makeText(PaymentDeatilsFormActivity.this, ""+response, Toast.LENGTH_SHORT).show();

                            if (message.equals("Success"))
                            {

                                Intent intent=new Intent(PaymentDeatilsFormActivity.this,ServiceDetailsActivity.class);

                                intent.putExtra("p_img",p_img);
                                intent.putExtra("p_price",p_price);
                                intent.putExtra("p_title",p_title);
                                intent.putExtra("p_discription",p_discription);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(PaymentDeatilsFormActivity.this, "hello="+e.toString(), Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        // Toast.makeText(PaymentDeatilsFormActivity.this, " error null", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id", pid);
                params.put("name", name);
                params.put("email", email);
                params.put("phone", phone);
                params.put("address1", address1);
                params.put("address2", address2);
                params.put("city", city);
                params.put("state", state);
                params.put("pin", pin);
                params.put("alternate_phone", alternatephone);
                params.put("user_id",user_id);
                params.put("payment_type",paymentType);
                params.put("service_time", time);
                params.put("service_date", date);


                return params;
            }
        };

        queue.getCache().clear();

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}


@SuppressLint("ValidFragment")
class DatePickerFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        PaymentDeatilsFormActivity.date=day+"/"+month+"/"+year;
        PaymentDeatilsFormActivity.datebtn.setText(day+"-"+month+"-"+year);
    }
}



 @SuppressLint("ValidFragment")
 class TimePickerFragment extends DialogFragment
        implements TimePickerDialog.OnTimeSetListener {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);


        // Create a new instance of TimePickerDialog and return it
        return new TimePickerDialog(getActivity(), this, hour, minute,
                DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        PaymentDeatilsFormActivity.time=hourOfDay+" : "+minute;

       PaymentDeatilsFormActivity.timebtn.setText(hourOfDay+":"+minute);
    }




}
